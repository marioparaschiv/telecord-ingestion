# Discord ingest protocol, route v1

A Discord producer is a gateway client that forwards raw dispatches from its own session to Telecord and answers a small, fixed set of requests. Any library that exposes the raw gateway dispatches and the REST fetch methods can be a producer.

This package ships the TypeScript schemas for every frame in this document (`./discord` entry point) and the conformance vectors in `vectors/discord.json` (section 12), exported as the subpath `./vectors/discord.json`.

## 1. Connection

```
wss://<ingest-host>/discord/v1?api=<N>&api_key=<key>
```

| Parameter | Meaning                                                                                                                              |
| --------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `api`     | The Discord gateway API version your library connects with, as a plain decimal. Every dispatch you forward has this version's shape. |
| `api_key` | The API key an operator issued for your Discord account.                                                                             |

- An unknown path or route version (for example `/discord/v2`) is refused with HTTP 404 before the key is read.
- There is no identify step. The key is bound to one Discord account ahead of time, and every frame on the connection belongs to that account.
- The server checks, in order: the API version (section 3), the API key, then that the key is bound to a Discord account. Each failure closes the socket with the code and reason in section 11.
- Only binary WebSocket frames are read. Text frames are ignored. `permessage-deflate` is supported.
- The largest frame the server accepts is announced in `HELLO` as `maxFrameSize` (100 MiB). A larger frame closes the socket at the WebSocket layer (close code 1009).

## 2. Frames

Every frame is a msgpack map:

```ts
{ op: string, d?: unknown, nonce?: string | null }
```

- `op` names the frame. Opcodes are SCREAMING_SNAKE_CASE strings.
- `d` is the payload. Frames that carry none send `nil` or omit it.
- `nonce` correlates a frame with its answer. `nil` and absent mean the same thing.
- A frame that is not valid msgpack, or has no `op`, is dropped without an answer.

## 3. Versions and `HELLO`

The server accepts a window of API versions, `min` to `max` inclusive: currently 9 and 10. It normalises the differences between them itself.

On an accepted connection the first frame the server sends is `HELLO`:

```ts
HELLO {
  heartbeatInterval: number,          // milliseconds between server PINGs
  versions: { min: number, max: number },
  maxFrameSize: number,               // bytes
  deprecation?: { until: number },
}
```

`deprecation` is present when your API version is the oldest the window accepts. Your version stays accepted until the window's `max` moves past `until`; upgrade before then.

| Declared version                | Result                                                                  |
| ------------------------------- | ----------------------------------------------------------------------- |
| missing, or not a plain decimal | closed with `4003 VERSION_REQUIRED <min>-<max>`                         |
| below `min`                     | closed with `4003 VERSION_UNSUPPORTED <min>-<max>`                      |
| `min` to `max`                  | `HELLO`                                                                 |
| above `max`                     | `HELLO`, then no `CHATS_FETCH`; every event frame is parked (see below) |

A parked frame is stored as sent and processed once the server supports its API version. It is acknowledged like any other frame, so a producer treats it as delivered. Dispatches inside the window that fail to parse are parked the same way.

Parking is capped per API key (10,000 frames by default). Once the cap is reached, further frames are answered with `ERROR` `PARK_LIMIT_REACHED` instead of `ACK` and are not stored.

Right after `HELLO` the server sends `CHATS_FETCH` (section 8), unless your API version is above the window.

## 4. Opcodes

| Opcode                                             | Direction                             | Payload                                    |
| -------------------------------------------------- | ------------------------------------- | ------------------------------------------ |
| `HELLO`                                            | server to producer                    | section 3                                  |
| `PING`                                             | server to producer                    | none                                       |
| `PONG`                                             | producer to server                    | none                                       |
| `ACK`                                              | server to producer                    | none; `nonce` names the acknowledged frame |
| `ERROR`                                            | server to producer                    | `{ code, message }`                        |
| the 16 forwarded dispatches                        | producer to server                    | section 6                                  |
| `CHATS_FETCH` / `CHATS_FETCH_RESULT`               | server to producer, answered in parts | section 8                                  |
| `MEDIA_FETCH` / `MEDIA_FETCH_RESULT`               | server to producer to server          | section 9                                  |
| `MESSAGES_FETCH` / `MESSAGES_FETCH_RESULT`         | server to producer to server          | section 9                                  |
| `ATTACHMENT_REFRESH` / `ATTACHMENT_REFRESH_RESULT` | server to producer to server          | section 9                                  |
| `PROBE` / `PROBE_RESULT`                           | server to producer to server          | section 9                                  |

Any other opcode sent by a producer is answered with `ERROR` `UNKNOWN_OPCODE`.

## 5. Heartbeat and delivery

**Heartbeat.** The server sends `PING` every `heartbeatInterval` milliseconds. Answer each with `PONG` (no payload, no nonce). Only `PONG` counts as liveness: if none arrives for more than 80 seconds, the server closes the socket with `4002 HEARTBEAT_TIMEOUT`.

**Delivery is at least once.**

- Every event frame must carry a `nonce`, unique among your unacknowledged frames. A frame without one is answered with `ERROR` `VALIDATION_ERROR` and no nonce, since it could never be acknowledged.
- The server answers `ACK` under the frame's nonce once it has durably accepted the frame. The acknowledgement is the same whether the dispatch changed anything, duplicated something already held, or matched nothing.
- Keep a bounded buffer of unacknowledged frames (about 1000). After a reconnect, resend them in their original order. On overflow drop the oldest and count the loss.
- The server processes frames idempotently, so a resend of a frame it already accepted is harmless.

An event the server cannot accept is answered with `ERROR` under its nonce:

| `code`               | Meaning                                                                                       | What to do                                                                                              |
| -------------------- | --------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| `VALIDATION_ERROR`   | The frame is malformed.                                                                       | Drop it; resending the same frame fails the same way.                                                   |
| `UNKNOWN_OPCODE`     | The route does not define the opcode.                                                         | Drop it.                                                                                                |
| `MISSING_PERMISSION` | The dispatch deletes content and the API key lacks the ingest delete permission.              | Drop it, or ask the operator for the permission.                                                        |
| `PARK_LIMIT_REACHED` | The frame had to be parked and your key's parked frames reached their cap; it was not stored. | Keep it buffered and resend it later. If your API version is above the window, switch to one inside it. |
| `INTERNAL_ERROR`     | The server failed.                                                                            | Keep it and resend later.                                                                               |

`message` is human-readable text for logs; do not parse it.

## 6. Forwarded events

Each forwarded dispatch is one frame. `op` is the dispatch name (the gateway's `t`) and `d` is the dispatch's `d`, exactly as Discord sent it.

```ts
MESSAGE_CREATE { ...d }   // the raw op-0 payload
```

The forwarded set is fixed. Forward only these dispatches:

```
MESSAGE_CREATE, MESSAGE_UPDATE, MESSAGE_DELETE, MESSAGE_DELETE_BULK,
MESSAGE_REACTION_ADD, MESSAGE_REACTION_REMOVE, MESSAGE_REACTION_REMOVE_EMOJI, MESSAGE_REACTION_REMOVE_ALL,
CHANNEL_CREATE, CHANNEL_UPDATE, CHANNEL_DELETE, GUILD_CREATE, GUILD_DELETE,
GUILD_MEMBER_UPDATE, GUILD_ROLE_UPDATE, GUILD_ROLE_DELETE
```

- Forward `GUILD_MEMBER_UPDATE` only for your own account's member.
- You may send any subset, for example after your filter rules (section 10) drop some.
- Each frame is self-contained.
- Deletions (`MESSAGE_DELETE`, `MESSAGE_DELETE_BULK`) and the removal of every reaction from a message require the ingest delete permission on the API key; without it they are answered with `MISSING_PERMISSION`.

## 7. Producer obligations

1. Forward dispatches unmodified; do not merge, split or enrich them.
2. Answer `MESSAGES_FETCH` through your library's fetch methods. You may call `message.fetchReference()` (or its equivalent) when a message arrives without `referenced_message`.
3. Build chat snapshots from the gateway cache, without REST calls.
4. Apply your filter rules (section 10) to events, to chat snapshots and to every request.
5. Buffer and resend unacknowledged frames (section 5).
6. Honour `HELLO`: heartbeat interval, frame size limit and deprecation.

## 8. Chat snapshots (`CHATS_FETCH`)

The snapshot is the only way the server learns which chats the account can see. It asks for one right after `HELLO`, then every 30 minutes while the connection stays open, never more than one at a time.

```ts
CHATS_FETCH {}                                   // server to producer, with a nonce
CHATS_FETCH_RESULT { part, done, ...chats }      // producer to server, under that nonce, once per part
```

- Answer in one or more parts under the request's nonce. `part` counts up from `0` in the order sent; `done: true` marks the last part.
- Parts must arrive in order. A part out of order, a malformed part, more than 10,000 parts, or a gap longer than 2 minutes between parts discards the snapshot.
- Each part is applied as it arrives: the chats it names become available immediately. A discarded snapshot revokes nothing.
- Once `done` arrives the snapshot is the account's complete chat list. A chat it no longer names is revoked when a later completed snapshot, at least 10 minutes on, still omits it. An empty snapshot revokes nothing.
- Apply your filter rules: leave out chats you do not forward.

Each part carries, chunked per guild:

| Field              | Content                                                                                                                                                                                        |
| ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `guilds`           | `[{ ...guild, roles, channels, self_member }]`: raw guild objects with their roles (`name` and `color` label role mentions), their channels (with `permission_overwrites`) and your own member |
| `private_channels` | raw DM and group DM channel objects                                                                                                                                                            |

Avatars come from the entities themselves (`icon`, `avatar`). The server fetches an image with `MEDIA_FETCH` only when its hash changed.

## 9. Requests

The server can ask a producer for exactly these things: `CHATS_FETCH` (section 8), `MEDIA_FETCH`, `MESSAGES_FETCH`, `ATTACHMENT_REFRESH` and `PROBE`. It can never ask for an arbitrary Discord call.

- A request carries a `nonce`. Answer once with the matching `<OP>_RESULT` under the same nonce.
- A result for a nonce the server is not waiting on is dropped. A result with the wrong opcode, or one that does not match the result schema, fails the request as malformed.
- The server waits 2 minutes for a result, 10 minutes for `MESSAGES_FETCH`.
- Every request is checked against your filter rules first. A request for a blocked channel is answered `{ ok: false, reason: 'filtered' }` without calling Discord. For id-based fetches each id is checked against its channel.

A declined result names one of these reasons:

| `reason`              | Meaning                                                                           |
| --------------------- | --------------------------------------------------------------------------------- |
| `access_lost`         | The account can no longer read the channel.                                       |
| `source_context_lost` | The message or channel the file came from is no longer reachable by this account. |
| `source_deleted`      | The source no longer exists for anyone.                                           |
| `filtered`            | Your filter rules block the channel; nothing was called.                          |

All but `source_deleted` only concern your account; the server may ask another account. An optional `message` (up to 512 characters) explains the failure for logs.

### `PROBE`

A liveness round trip that does no work.

```ts
PROBE { token: string }
PROBE_RESULT { token: string }   // echo the token
```

### `MEDIA_FETCH`

Download one CDN url through your session and upload it to a presigned POST.

```ts
MEDIA_FETCH {
  fileName: string,                                        // the object key; echo it in the result
  url: string,
  maxBytes: number,
  upload: { url: string, fields: Record<string, string> },  // at most 32 fields
}

MEDIA_FETCH_RESULT {
  fileName: string,
  ok: boolean,
  bytes?: number,
  reason?: 'access_lost' | 'source_context_lost' | 'source_deleted' | 'filtered',
  message?: string,
}
```

- Upload with a multipart `POST` to `upload.url`: every entry of `fields` as a form field, then the file. Never send more than `maxBytes`; the upload policy rejects it anyway.
- The result is a hint. The server checks the uploaded object itself before using it.

### `ATTACHMENT_REFRESH`

Re-sign one lapsed CDN url. There is no upload: return the fresh url and the server fetches the file itself.

```ts
ATTACHMENT_REFRESH { fileName: string, url: string }

ATTACHMENT_REFRESH_RESULT {
  fileName: string,
  ok: boolean,
  url?: string,                  // the re-signed url
  reason?: 'access_lost' | 'source_context_lost' | 'filtered',
  code?: number,                 // Discord's own error code, when the call failed
  message?: string,
}
```

Discord answers a lapsed signature and a deleted attachment with the same 404, so `source_deleted` is not accepted here. Pass Discord's error `code` instead; the server derives deletion from it.

### `MESSAGES_FETCH`

Read messages by id or one page of history.

```ts
MESSAGES_FETCH
  | { channelId: string, ids: string[] }                                  // 1 to 100 snowflakes
  | { channelId: string, before?: string, after?: string, limit: number } // limit 1 to 100

MESSAGES_FETCH_RESULT {
  ok: boolean,
  messages?: object[],           // up to 100 raw message objects as the API returned them, each with its id
  reason?: 'access_lost' | 'source_deleted' | 'filtered',
  message?: string,
}
```

- Handle rate limits (HTTP 429) in your client and retry; the server does not rate-limit this request and waits long enough for it.
- The range form exists for backfill and is not sent yet.

## 10. Filter rules

Filters are yours to configure; the server never sees them. The reference producer uses ordered first-match rules with a configurable default, matching on `type` (`dm`, `group_dm`, `guild`), `guildId`, `channelId` and the dispatch name, and drops DMs and group DMs by default. Whatever you use, apply the same rules to events, to chat snapshots and to every request.

## 11. Close codes

| Code | Reason                            | Meaning                                                |
| ---- | --------------------------------- | ------------------------------------------------------ |
| 4001 | `API_KEY_REQUIRED`                | No `api_key` on the URL.                               |
| 4001 | `INVALID_API_KEY`                 | The key is unknown.                                    |
| 4001 | `API_KEY_DISABLED`                | The key was disabled.                                  |
| 4001 | `API_KEY_EXPIRED`                 | The key expired, at connect time or while connected.   |
| 4001 | `MISSING_PERMISSION`              | The key lacks the ingest write permission.             |
| 4001 | `IP_NOT_ALLOWED`                  | The key is restricted to other addresses.              |
| 4001 | `IDENTITY_UNREGISTERED`           | The key is not bound to a producer account.            |
| 4001 | `PLATFORM_MISMATCH`               | The key is bound to an account on another platform.    |
| 4001 | `Authentication error`            | The server failed while checking the key; retry later. |
| 4002 | `HEARTBEAT_TIMEOUT`               | No `PONG` in time.                                     |
| 4003 | `VERSION_REQUIRED <min>-<max>`    | No API version, or not a plain decimal.                |
| 4003 | `VERSION_UNSUPPORTED <min>-<max>` | The API version is outside the accepted window.        |

After a `4001` other than `Authentication error`, do not reconnect until the configuration changes. After a `4003`, upgrade your library. After anything else, reconnect with backoff and resend your unacknowledged frames.

## 12. Conformance vectors

`vectors/discord.json` lists frames and the server's expected answers. The same file runs against the server in its test suite, so it matches the server's behaviour.

```ts
{
  url: string,        // the connection URL event and request vectors use unless they set their own
  vectors: Vector[],
}
```

Placeholders in strings:

| Placeholder          | Value                                                   |
| -------------------- | ------------------------------------------------------- |
| `{min}`, `{max}`     | the window from `HELLO` (or from a `4003` close reason) |
| `{min-1}`, `{max+1}` | one version below and above the window                  |
| `{key}`              | a valid key bound to a Discord account                  |
| `{foreignKey}`       | a valid key bound to an account on another platform     |
| `{unboundKey}`       | a valid key bound to no producer account                |
| `{parkLimit}`        | the most frames the server parks per key                |

A string that is exactly one numeric placeholder, such as `"{max}"`, stands for the number. `{ "$bytes": "<base64>" }` stands for a msgpack `bin` value.

Each vector has an `id`, a `description` and a `kind`:

- **`connect`**: open `url`, then expect one of `{ status }` (HTTP refusal), `{ close: { code, reason } }` or `{ frame }` (the first frame). When `chatsFetch` is set, it says whether `CHATS_FETCH` follows `HELLO`.
- **`event`**: connect, wait for `HELLO`, send `send`, and expect the answer `expect` (`ACK` or `ERROR`). `outcome` says what happened to the frame: `accepted`, `refused` or `parked`. `alreadyParked`, when set, is how many frames the key has parked before the vector starts.
- **`request`**: the server sends `request` (with a nonce of its choosing, omitted here) and the producer answers with the frames in `reply` under that nonce. `outcome` is `accepted` when the server takes the result and `refused` when it drops it as malformed. For `CHATS_FETCH`, `chats` lists the platform ids of the chats that are available to the account afterwards: every chat the snapshot names when it is `accepted`, none when it is `refused`.

Frames compare exactly, except that an `ERROR`'s `message` is free text and only `code` (and `nonce`, when given) are specified.
